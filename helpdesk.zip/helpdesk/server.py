# First we import parts of the frameworks we're using:
#
# Flask <http://flask.pocoo.org> is a simple framework for building web
# applications in Python. It handles basic things like parsing incoming
# HTTP requests and generating responses.
#
# Flask-RESTful <https://flask-restful.readthedocs.io/> is an add-on to Flask
# that makes it easier to build web applications that adhere to the REST
# architectural style.

from flask import (Flask, Response, request, render_template, make_response,
                   redirect)
from flask_restful import Api, Resource, reqparse


# Next we import some standard Python libraries and functions:
#
# json <https://docs.python.org/3/library/json.html> for loading a JSON file
# from disk (our "database") into memory.
#
# random <https://docs.python.org/3/library/random.html> and string
# <https://docs.python.org/3/library/string.html> to help us generate
# unique IDs for help tickets from lowercase letters and digits.
#
# wraps <https://docs.python.org/3/library/functools.html#functools.wraps>
# is just a convenience function that will help us implement authentication.

import json
import random
import string
from functools import wraps

# Load data from disk.
# This simply loads the data from our "database," which is just a JSON file.
with open('data.json') as data:
    data = json.load(data)


# The next three functions implement simple authentication.

# Check that username and password are OK; DON'T DO THIS FOR REAL
def check_auth(username, password):
    return username == 'admin' and password == 'secret'


# Issue an authentication challenge
def authenticate():
    return Response(
        'Please authenticate yourself', 401,
        {'WWW-Authenticate': 'Basic realm="helpdesk"'})


# Decorator for methods that require authentication
def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            return authenticate()
        return f(*args, **kwargs)
    return decorated


# The following are three  helper functions used in our resource classes.

# Generate a unique ID for a new help ticket.
# By default this will consist of six lowercase numbers and letters.
def generate_id(size=3, chars=string.digits):
    return ''.join(random.choice(chars) for _ in range(size))


# Now we define three incoming HTTP request parsers using the Flask-RESTful
# framework <https://flask-restful.readthedocs.io/en/latest/reqparse.html>.
#
# The first (new_ticket_parser) parses incoming POST requests and checks
# that they have the required values.

# Helper function new_ticket_parser. Raises an error if the string x
# is empty (has zero length).
def nonempty_string(x):
    s = str(x)
    if len(x) == 0:
        raise ValueError('string is empty')
    return s


# Specify the data necessary to create a new ticket.
# "flightNumber" and "name" are all required values.
new_ticket_parser = reqparse.RequestParser()
for arg in ['flightNumber', 'name']:
    new_ticket_parser.add_argument(
        arg, type=nonempty_string, required=True,
        help="'{}' is a required value".format(arg))

# Specify the data necessary to find a ticket.
# "flightNumber" and "ticket_num" are all required values.
ticket_parser = reqparse.RequestParser()
for arg in ['flightNumber', 'ticket_num']:
    ticket_parser.add_argument(
        arg, type=nonempty_string, required=True,
        help="'{}' is a required value".format(arg))


# Then we define a couple of helper functions for inserting data into HTML
# templates (found in the templates/ directory). See
# <http://flask.pocoo.org/docs/latest/quickstart/#rendering-templates>.

# Given the data for a list of flights, generate an HTML representation
# of that list.
def render_flight_list_as_html():
    return render_template(
        'availableFlights.html',
        flights=data['flights'])


# Given the data for a flight, generate an HTML representation
def render_flight_as_html(flightNumber, flight):
    return render_template(
        'flight.html',
        flightNumber=flightNumber, flight=flight)


# Given the data for a ticket, generate an HTML representation
def render_ticket_as_html(flightNumber, ticket_num, ticket):
    return render_template(
        'ticket.html',
        flightNumber=flightNumber, ticket_num=ticket_num, ticket=ticket)

# Now we can start defining our resource classes. We define four classes:
# Ticket, Flight, FlightList, TicketList.
# All of them accept GET requests except TicketList,
# and TicketList also accepts POST requests.


# Define our ticket resource.
class Ticket(Resource):
    # Respond with an HTML representation.
    def get(self):
        ticket = ticket_parser.parse_args()
        flightNumber = (ticket['flightNumber']).strip()
        ticket_num = (ticket['ticket_num']).strip()
        return make_response(
            render_ticket_as_html(flightNumber, ticket_num,
                data['flights'][flightNumber]['tickets'][ticket_num]), 200)


# Define our flight resource.
class Flight(Resource):
    # Respond with an HTML representation.
    def get(self, flightNumber):
        return make_response(
            render_flight_as_html(flightNumber,
                    data['flights'][flightNumber]), 200)


# Define our flight list resource.
class FlightList(Resource):

    # Respond with an HTML representation of the flight list
    def get(self):
        return make_response(
            render_flight_list_as_html(), 200)


class TicketList(Resource):

    # Add a new ticket to the list, and respond with an HTML
    # representation of the created ticket.
    def post(self):
        ticket = new_ticket_parser.parse_args()
        flightNumber = (ticket['flightNumber']).strip()
        ticket_num = generate_id()
        del ticket['flightNumber']
        data['flights'][flightNumber]['tickets'][ticket_num] = ticket
        return make_response(
            render_ticket_as_html(flightNumber, ticket_num,  # redirect to ticket created
                    data['flights'][flightNumber]['tickets'][ticket_num]), 201)


# After defining our resource classes, we define how URLs are assigned to
# resources by mapping resource classes to URL patterns.

app = Flask(__name__)
api = Api(app)
api.add_resource(FlightList, '/availableFlights')
api.add_resource(Flight, '/flights/<string:flightNumber>')
api.add_resource(TicketList, '/TicketList')
api.add_resource(Ticket, '/tickets/<string:flightNumber>/<string:ticket_num>', '/tickets')



# There is no resource mapped to the root path (/), so if a request comes in
# for that, redirect to the availableFlights resource.

@app.route('/')
def index():
    return redirect(api.url_for(FlightList), code=303)


# Finally we add some headers to all of our HTTP responses which will allow
# JavaScript loaded from other domains and running in the browser to load
# representations of our resources (for security reasons, this is disabled
# by default.

@app.after_request
def after_request(response):
    response.headers.add(
        'Access-Control-Allow-Origin', '*')
    response.headers.add(
        'Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add(
        'Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE')
    return response


# Now we can start the server.

if __name__ == '__main__':
    app.run(
        host='0.0.0.0',
        port=5556,
        debug=True,
        use_debugger=False,
        use_reloader=False)
